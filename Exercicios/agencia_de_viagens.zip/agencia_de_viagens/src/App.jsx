import './App.css'
import Header from './assets/Componentes/header'
import Escocia from './assets/Componentes/Escocia'
import Grand from './assets/Componentes/Grand'
import Katmandu from './assets/Componentes/Katmandu'
import Arubu from './assets/Componentes/Arubu'
import China from './assets/Componentes/China'
function App() {

  return (
    <>
      <Header />
      <Escocia/>
      <Grand/>
      <Katmandu/>
      <China />
      <Arubu />
    </>
  )
}

export default App
