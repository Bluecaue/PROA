import Style from './Escocia.module.css'


function Escocia(){
    return(
        <div className={Style.Escocia}>
            <h1>
                Venha conhecer a cultura da Escocia
            </h1>
        </div>
    )
}

export default Escocia