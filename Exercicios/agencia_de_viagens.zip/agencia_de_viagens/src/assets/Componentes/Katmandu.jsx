import Style from './Katmandu.module.css'

function Katmandu(){
    return(
        <div className={Style.Katmandu}>

        </div>
    )
}

export default Katmandu