import Style from './China.module.css'

function China(){
    return(
        <div className={Style.China}>

        </div>
    )
}

export default China