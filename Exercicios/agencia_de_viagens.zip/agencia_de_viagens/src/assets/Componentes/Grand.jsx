import Style from './Grand.module.css'

function Grand(){
    return(
        <div className={Style.Grand}>

        </div>
    )
}

export default Grand