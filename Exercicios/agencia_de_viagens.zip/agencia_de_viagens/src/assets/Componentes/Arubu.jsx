import Style from './Arubu.module.css'

function Arubu(){
    return(
        <div className={Style.Arubu}>

        </div>
    )
}

export default Arubu