import Style from './header.module.css'
import travel from './img/travel.jpg'
import search from './img/lupa.png'

function header(){

    return (
        <div>

            <header className={Style.menu}>
                <nav className={Style.navleft}>
                        <img src={travel} alt="logo" className={Style.logo}/>
                </nav>
                <nav className={Style.navcenter}>
                    <ul className={Style.ul}>
                        <a href=""><li>Home</li></a>
                        <a href=""><li>Grand Canyon</li></a>
                        <a href=""><li>Escocia</li></a>
                        <a href=""><li>Katmandu</li></a>
                        <a href=""><li>Muralha da China</li></a>
                        <a href=""><li>Aruba</li></a>
                    </ul>
                    
                </nav>
                <nav className={Style.navright}>
                    
                    <input type="text" maxLength={25}/>
                    <img src={search} alt="busca" />
                </nav>
            </header>

        </div>
    )
}

export default header